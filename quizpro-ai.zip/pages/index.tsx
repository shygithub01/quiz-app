import { useState } from 'react';
import Quiz from '../components/Quiz';

export default function Home() {
  const [text, setText] = useState('');
  const [quizData, setQuizData] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit() {
    setLoading(true);
    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await res.json();
    setQuizData(data);
    setLoading(false);
  }

  return (
    <div style={{ padding: '2rem' }}>
      <h1>QuizPro.ai</h1>
      <p>AI-Powered Quiz Creation from Any File</p>
      <textarea rows={10} style={{ width: '100%' }} value={text} onChange={e => setText(e.target.value)} placeholder="Paste text here..." />
      <button onClick={handleSubmit} disabled={loading}>Generate Quiz</button>
      {quizData && <Quiz data={quizData} />}
    </div>
  );
}
