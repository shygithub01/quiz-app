import { useState } from 'react';
import Result from './Result';

export default function Quiz({ data }: { data: any }) {
  const questions = data.result.split(/\n\n/).map((q: string) => q.trim());
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);

  const q = questions[index];
  const parts = q.split('\n');
  const question = parts[0];
  const options = parts.slice(1, 5);
  const answerLine = parts.find(p => p.startsWith('Answer:'));
  const correct = answerLine ? answerLine.slice(-1).trim().toUpperCase() : null;

  function handleAnswer(letter: string) {
    if (letter === correct) setScore(score + 1);
    setIndex(index + 1);
  }

  if (index >= questions.length) return <Result score={score} total={questions.length} />;

  return (
    <div>
      <h2>{question}</h2>
      {options.map((opt, i) => (
        <button key={i} onClick={() => handleAnswer(opt.charAt(0).toUpperCase())}>
          {opt}
        </button>
      ))}
    </div>
  );
}
