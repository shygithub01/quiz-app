export default function Result({ score, total }: { score: number, total: number }) {
  return (
    <div>
      <h2>Quiz Complete!</h2>
      <p>You scored {score} out of {total} ({Math.round(score / total * 100)}%)</p>
    </div>
  );
}
